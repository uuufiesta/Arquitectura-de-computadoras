/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;

char *IEEE_P_3499444699;
char *IEEE_P_3620187407;
char *IEEE_P_2592010699;
char *STD_STANDARD;


int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    ieee_p_2592010699_init();
    ieee_p_3499444699_init();
    ieee_p_3620187407_init();
    work_a_0812470865_1180717711_init();
    work_a_2581789780_3212880686_init();
    work_a_0897092005_3742311615_init();
    work_a_2807972004_2271782590_init();
    work_a_3443886858_2716009070_init();
    work_a_2299080931_3943019290_init();
    work_a_1708390461_0232453779_init();
    work_a_3809436715_0044882199_init();
    work_a_2362938796_0616011313_init();
    work_a_1906016609_3926242313_init();
    work_a_3535441055_0566505410_init();
    work_a_0936057823_1010678102_init();
    work_a_0995404692_1631900237_init();
    work_a_0720059364_1316594356_init();
    work_a_4038899745_2097448524_init();
    work_a_0012266766_4013901780_init();
    work_a_0595222044_3050498326_init();
    work_a_1512705748_2372691052_init();


    xsi_register_tops("work_a_1512705748_2372691052");

    IEEE_P_3499444699 = xsi_get_engine_memory("ieee_p_3499444699");
    IEEE_P_3620187407 = xsi_get_engine_memory("ieee_p_3620187407");
    IEEE_P_2592010699 = xsi_get_engine_memory("ieee_p_2592010699");
    xsi_register_ieee_std_logic_1164(IEEE_P_2592010699);
    STD_STANDARD = xsi_get_engine_memory("std_standard");

    return xsi_run_simulation(argc, argv);

}
